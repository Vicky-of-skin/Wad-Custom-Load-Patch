﻿#include <windows.h>
#include <psapi.h>
#include <string>
#include <filesystem>
#include <vector>
#include <fstream>
#include <chrono>
#include <ctime>
#include <process.h>
#include <algorithm>

#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "user32.lib")
#pragma comment(lib, "kernel32.lib")

#include "MinHook_1.3.4_lib/include/MinHook.h"

// ==================== 用户配置（调试模式） ====================
#define SKIN_FOLDER_NAME "Myskin"
#define ENABLE_LOG 1                      // 1=启用日志, 0=禁用
#define ENABLE_CRASH_PATCH1 1             // ← 过崩溃1，开关
#define ENABLE_CRASH_PATCH2 1             // ← 过崩溃2，开关
#define USE_PATTERN_SCAN 1                // 特征码扫描保持开启
#define ENABLE_HARDWARE_BREAKPOINT 1      // ← 硬件断点 开关
// =========================================================

EXTERN_C IMAGE_DOS_HEADER __ImageBase;

UINT8 wad_check_Buff[] = { 0xB8, 0x01, 0x00, 0x00, 0x00 };
UINT8 wad_repeat_Buff[] = { 0xEB };

std::vector<std::string> vec_path;
std::ofstream g_log_file;

// ==================== 固定地址（兜底） ====================
#define FIXED_GLOBAL_WAD     0x1405E6146
#define FIXED_GLOBAL_CALL    0x1405E0FA0
#define FIXED_WAD_CHECK      0x141184A11
#define FIXED_WAD_REPEAT     0x14118001F

// ==================== 特征码 ====================
const BYTE PATTERN_GLOBALWAD[] = {
    0x40, 0x53, 0x48, 0x83, 0xEC, 0x20, 0x48, 0x8D, 0x15, 0x00, 0x00, 0x00, 0x00,
    0x48, 0x8B, 0xD9, 0xE8, 0x00, 0x00, 0x00, 0x00,
    0x48, 0x8D, 0x15, 0x00, 0x00, 0x00, 0x00,
    0x48, 0x8B, 0xCB, 0xE8
};
const char* MASK_GLOBALWAD = "xxxxxxxxx????xxxx????xxx????xxxx";

const BYTE PATTERN_WADCHECK[] = {
    0x48, 0x89, 0x44, 0x24, 0x28, 0xB9, 0xA0, 0x02, 0x00, 0x00
};
const char* MASK_WADCHECK = "xxxxxxxxxx";

const BYTE PATTERN_WADREPEAT[] = {
    0x48, 0x85, 0xC9, 0x7F, 0xCA, 0x48, 0x8D, 0x04,
    0x37, 0x4C, 0x3B, 0xC0, 0x74, 0x05, 0x4D, 0x39,
    0x18, 0x74, 0x0B
};
const char* MASK_WADREPEAT = "xxxxxxxxxxxxxxxxxxx";

uintptr_t g_BaseAddress = 0;
uintptr_t g_GlobalWad = FIXED_GLOBAL_WAD;
uintptr_t g_GlobalCall = FIXED_GLOBAL_CALL;
uintptr_t g_WadCheck = FIXED_WAD_CHECK;
uintptr_t g_WadRepeat = FIXED_WAD_REPEAT;
DWORD id;

// ==================== 日志 ====================
std::string GetTime() {
    auto now = std::chrono::system_clock::now();
    auto t = std::chrono::system_clock::to_time_t(now);
    struct tm tm;
    localtime_s(&tm, &t);
    char buf[64];
    strftime(buf, sizeof(buf), "[%Y-%m-%d %H:%M:%S]", &tm);
    return std::string(buf);
}

void Log(const std::string& msg) {
#if ENABLE_LOG
    if (g_log_file.is_open()) {
        g_log_file << GetTime() << " " << msg << std::endl;
        g_log_file.flush();
    }
#endif
}

void LogHex(const std::string& msg, uintptr_t val) {
#if ENABLE_LOG
    char buf[256];
    sprintf_s(buf, sizeof(buf), "%s 0x%llX", msg.c_str(), (unsigned long long)val);
    Log(buf);
#endif
}

// ==================== 内存操作 ====================
bool IsReadable(uintptr_t addr) {
    if (!addr) return false;
    MEMORY_BASIC_INFORMATION mbi;
    if (VirtualQuery((LPCVOID)addr, &mbi, sizeof(mbi)) == 0) return false;
    return (mbi.Protect & (PAGE_READONLY | PAGE_READWRITE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE)) != 0;
}

bool WriteMem(void* addr, void* buf, size_t size) {
    DWORD old;
    if (!VirtualProtect(addr, size, PAGE_EXECUTE_READWRITE, &old)) {
        Log("VirtualProtect 失败");
        return false;
    }
    SIZE_T written;
    if (!WriteProcessMemory(GetCurrentProcess(), addr, buf, size, &written)) {
        Log("WriteProcessMemory 失败");
        VirtualProtect(addr, size, old, &old);
        return false;
    }
    VirtualProtect(addr, size, old, &old);
    Log("写入成功 " + std::to_string(size) + " 字节");
    return true;
}

uintptr_t ReadCall(uintptr_t addr) {
    if (!addr) return 0;
    BYTE op;
    if (!ReadProcessMemory(GetCurrentProcess(), (LPCVOID)addr, &op, 1, nullptr)) return 0;
    if (op != 0xE8) return 0;
    int32_t off;
    if (!ReadProcessMemory(GetCurrentProcess(), (LPCVOID)(addr + 1), &off, 4, nullptr)) return 0;
    return addr + 5 + off;
}

// ==================== 特征码扫描 ====================
class PatternScanner {
    uintptr_t m_base;
    SIZE_T m_size;
    HANDLE m_hProcess;

public:
    PatternScanner() : m_hProcess(GetCurrentProcess()) {
        m_base = (uintptr_t)GetModuleHandleA(nullptr);
        if (m_base) {
            MODULEINFO mi = {};
            if (GetModuleInformation(m_hProcess, GetModuleHandleA(nullptr), &mi, sizeof(mi))) {
                m_size = mi.SizeOfImage;
            }
        }
        LogHex("Scanner base", m_base);
        Log("Scanner size: " + std::to_string(m_size));
    }

    uintptr_t Find(const BYTE* pattern, const char* mask, size_t len, int offset = 0) {
        if (!m_base || !m_size) {
            Log("Scanner: Invalid module!");
            return 0;
        }
        Log("Searching " + std::to_string(len) + " bytes...");
        const size_t CHUNK = 8192;
        std::vector<BYTE> buf(CHUNK + len);
        for (uintptr_t i = 0; i < m_size; i += CHUNK - len) {
            size_t toRead = min(CHUNK, m_size - i);
            SIZE_T read;
            if (!ReadProcessMemory(m_hProcess, (LPCVOID)(m_base + i), buf.data(), toRead, &read)) {
                continue;
            }
            if (read < len) break;
            for (size_t j = 0; j <= read - len; j++) {
                bool found = true;
                for (size_t k = 0; k < len; k++) {
                    if (mask[k] == 'x') {
                        if (pattern[k] != buf[j + k]) {
                            found = false;
                            break;
                        }
                    }
                }
                if (found) {
                    uintptr_t result = m_base + i + j + offset;
                    LogHex("Found at", result);
                    return result;
                }
            }
        }
        Log("NOT FOUND!");
        return 0;
    }
};

// ==================== 崩溃捕获（调试用） ====================
std::string GetModuleNameByAddress(DWORD64 addr) {
    HMODULE hMod = NULL;
    HANDLE hProcess = GetCurrentProcess();
    HMODULE modules[1024];
    DWORD needed;
    if (EnumProcessModules(hProcess, modules, sizeof(modules), &needed)) {
        for (size_t i = 0; i < needed / sizeof(HMODULE); i++) {
            MODULEINFO info;
            if (GetModuleInformation(hProcess, modules[i], &info, sizeof(info))) {
                if (addr >= (DWORD64)info.lpBaseOfDll && 
                    addr < (DWORD64)info.lpBaseOfDll + info.SizeOfImage) {
                    char name[MAX_PATH];
                    GetModuleBaseNameA(hProcess, modules[i], name, MAX_PATH);
                    return std::string(name) + " + 0x" + 
                           std::to_string(addr - (DWORD64)info.lpBaseOfDll);
                }
            }
        }
    }
    return "Unknown";
}

// 调试模式专用异常处理器 - 记录崩溃地址，不修复
LONG WINAPI DebugExceptionHandler(PEXCEPTION_POINTERS ex) {
    DWORD64 crashAddr = (DWORD64)ex->ExceptionRecord->ExceptionAddress;
    DWORD code = ex->ExceptionRecord->ExceptionCode;
    
    Log("========================================");
    Log("【!!! 崩溃捕获 !!!】");
    LogHex("  异常代码: ", code);
    LogHex("  崩溃地址: ", crashAddr);
    
    // 如果是访问违规，记录更多信息
    if (code == EXCEPTION_ACCESS_VIOLATION) {
        DWORD64 faultAddr = (DWORD64)ex->ExceptionRecord->ExceptionInformation[1];
        LogHex("  访问地址: ", faultAddr);
        Log("  操作类型: " + std::string(
            ex->ExceptionRecord->ExceptionInformation[0] == 0 ? "读取" :
            ex->ExceptionRecord->ExceptionInformation[0] == 1 ? "写入" : "执行"
        ));
    }
    
    // 记录崩溃位置（模块名+偏移）
    std::string moduleInfo = GetModuleNameByAddress(crashAddr);
    Log("  崩溃位置: " + moduleInfo);
    
    Log("========================================");
    Log("【下一步】");
    Log("  1. 打开 Cheat Engine，附加游戏进程");
    Log("  2. 按 Ctrl+G，输入崩溃地址: 0x" + std::to_string(crashAddr));
    Log("  3. 查看该地址附近的字节，找到特征码");
    Log("  4. 更新代码里的 PATTERN_* 数组");
    Log("========================================");
    
    // 让游戏继续崩溃（不修复）
    return EXCEPTION_CONTINUE_SEARCH;
}

// ==================== 地址初始化（特征码优先 + 固定地址兜底） ====================
bool InitAddresses() {
    Log("========================================");
    Log("InitAddresses START");
    Log("特征码扫描: " + std::string(USE_PATTERN_SCAN ? "启用" : "禁用"));
    Log("========================================");

    g_BaseAddress = (uintptr_t)GetModuleHandleA(nullptr);
    if (!g_BaseAddress) {
        Log("Failed to get base address!");
        return false;
    }
    LogHex("Game base", g_BaseAddress);

#if USE_PATTERN_SCAN
    PatternScanner scanner;

    // 1. GlobalWad
    Log("[1] GlobalWad");
    uintptr_t a1 = scanner.Find(PATTERN_GLOBALWAD, MASK_GLOBALWAD, sizeof(PATTERN_GLOBALWAD));
    if (a1) {
        uintptr_t addr = a1 + 6;
        if (IsReadable(addr)) {
            g_GlobalWad = addr;
            LogHex("  GlobalWad (扫描成功)", g_GlobalWad);
        } else {
            g_GlobalWad = FIXED_GLOBAL_WAD;
            LogHex("  GlobalWad (不可读，使用固定地址)", g_GlobalWad);
        }
        uintptr_t call = ReadCall(a1 + 0x10);
        if (call && IsReadable(call)) {
            g_GlobalCall = call;
            LogHex("  GlobalCall (扫描成功)", g_GlobalCall);
        } else {
            g_GlobalCall = FIXED_GLOBAL_CALL;
            LogHex("  GlobalCall (不可读，使用固定地址)", g_GlobalCall);
        }
    } else {
        g_GlobalWad = FIXED_GLOBAL_WAD;
        g_GlobalCall = FIXED_GLOBAL_CALL;
        LogHex("  GlobalWad (未找到，使用固定地址)", g_GlobalWad);
        LogHex("  GlobalCall (未找到，使用固定地址)", g_GlobalCall);
    }

    // 2. WadCheck
    Log("[2] WadCheck");
    uintptr_t a2 = scanner.Find(PATTERN_WADCHECK, MASK_WADCHECK, sizeof(PATTERN_WADCHECK));
    if (a2) {
        uintptr_t addr = a2 + 0x0F;
        if (IsReadable(addr)) {
            g_WadCheck = addr;
            LogHex("  WadCheck (扫描成功 + 0x0F)", g_WadCheck);
        } else {
            g_WadCheck = FIXED_WAD_CHECK;
            LogHex("  WadCheck (不可读，使用固定地址)", g_WadCheck);
        }
    } else {
        g_WadCheck = FIXED_WAD_CHECK;
        LogHex("  WadCheck (未找到，使用固定地址)", g_WadCheck);
    }

    // 3. WadRepeat
    Log("[3] WadRepeat");
    uintptr_t a3 = scanner.Find(PATTERN_WADREPEAT, MASK_WADREPEAT, sizeof(PATTERN_WADREPEAT));
    if (a3) {
        uintptr_t addr = a3 + 0x1E;
        if (IsReadable(addr)) {
            g_WadRepeat = addr;
            LogHex("  WadRepeat (扫描成功 + 0x1E)", g_WadRepeat);
        } else {
            g_WadRepeat = FIXED_WAD_REPEAT;
            LogHex("  WadRepeat (不可读，使用固定地址)", g_WadRepeat);
        }
    } else {
        g_WadRepeat = FIXED_WAD_REPEAT;
        LogHex("  WadRepeat (未找到，使用固定地址)", g_WadRepeat);
    }
#else
    Log("特征码扫描已禁用，全部使用固定地址");
    g_GlobalWad = FIXED_GLOBAL_WAD;
    g_GlobalCall = FIXED_GLOBAL_CALL;
    g_WadCheck = FIXED_WAD_CHECK;
    g_WadRepeat = FIXED_WAD_REPEAT;
#endif

    Log("========================================");
    Log("最终使用的地址:");
    LogHex("  GlobalWad  ", g_GlobalWad);
    LogHex("  GlobalCall ", g_GlobalCall);
    LogHex("  WadCheck   ", g_WadCheck);
    LogHex("  WadRepeat  ", g_WadRepeat);
    Log("========================================");
    return true;
}

// ==================== WAD加载 ====================
typedef __int64(__fastcall* FnLoad)(unsigned __int64, const char*);

void LoadWAD(DWORD64 rcx, DWORD64 call, std::string name) {
    if (!call) return;
    char buf[1024] = {};
    strcpy_s(buf, name.c_str());
    ((FnLoad)call)(rcx, buf);
    Log("加载: " + name);
}

// ==================== 硬件断点 ====================
DWORD WINAPI SetBP(LPVOID tid) {
    Log("设置硬件断点...");
    HANDLE h = OpenThread(THREAD_ALL_ACCESS, TRUE, (DWORD)(DWORD_PTR)tid);
    if (!h) { Log("打开线程失败"); return 1; }
    SuspendThread(h);
    CONTEXT ctx = {};
    ctx.ContextFlags = CONTEXT_ALL;
    GetThreadContext(h, &ctx);
    ctx.Dr0 = g_GlobalWad;
    ctx.Dr7 = 0x1;
    SetThreadContext(h, &ctx);
    ResumeThread(h);
    CloseHandle(h);
    LogHex("断点设置成功", g_GlobalWad);
    return 0;
}

LONG WINAPI ExceptionHandler(PEXCEPTION_POINTERS ex) {
    if (ex->ExceptionRecord->ExceptionCode == EXCEPTION_SINGLE_STEP &&
        ex->ExceptionRecord->ExceptionAddress == (PVOID)g_GlobalWad) {
        Log("=== 触发断点 ===");
        ex->ContextRecord->Dr7 = 0;
        ex->ContextRecord->Dr0 = 0;
        for (auto& s : vec_path) {
            LoadWAD(ex->ContextRecord->Rcx, g_GlobalCall, s);
        }
        Log("加载完成");
        return EXCEPTION_CONTINUE_EXECUTION;
    }
    return EXCEPTION_CONTINUE_SEARCH;
}

// ==================== BreakPoint 导出函数 ====================
extern "C" __declspec(dllexport) void WINAPI BreakPoint() {
    Log("BreakPoint 启动");
    
    // 添加崩溃捕获处理器（调试用）
    AddVectoredExceptionHandler(1, (PVECTORED_EXCEPTION_HANDLER)DebugExceptionHandler);
    AddVectoredExceptionHandler(1, (PVECTORED_EXCEPTION_HANDLER)ExceptionHandler);
    
#if ENABLE_HARDWARE_BREAKPOINT
    Log("硬件断点: 启用");
    _beginthreadex(0, 0, (_beginthreadex_proc_type)SetBP, (void*)(DWORD_PTR)id, 0, 0);
#else
    Log("硬件断点: 禁用 (跳过SetBP)");
#endif

    while (true) Sleep(1000);
}

// ==================== 查找WAD ====================
int FindWAD(std::wstring path) {
    if (!std::filesystem::exists(path)) {
        Log("皮肤文件夹不存在");
        return 0;
    }
    int cnt = 0;
    for (auto& e : std::filesystem::directory_iterator(path)) {
        if (e.is_directory()) continue;
        std::string p = e.path().string();
        if (p.find(".wad.client") == std::string::npos) continue;
        size_t pos = p.find_last_of('\\') + 1;
        std::string name = p.substr(pos);
        name = std::string(SKIN_FOLDER_NAME) + "/" + name.substr(0, name.rfind("."));
        vec_path.push_back(name);
        cnt++;
        Log("发现: " + name);
    }
    Log("共找到 " + std::to_string(cnt) + " 个");
    return cnt;
}

// ==================== 工具函数 ====================
std::string GetDllDir() {
    char path[MAX_PATH];
    GetModuleFileNameA((HMODULE)&__ImageBase, path, MAX_PATH);
    std::string s(path);
    size_t pos = s.find_last_of('\\');
    return pos != std::string::npos ? s.substr(0, pos) : "";
}

std::string GetAppPath() {
    char path[260] = {};
    GetModuleFileNameA(0, path, 260);
    std::string s(path);
    size_t pos = s.find_last_of('\\');
    return pos != std::string::npos ? s.substr(0, pos) : "";
}

std::wstring A2W(std::string& s) {
    int len = MultiByteToWideChar(CP_ACP, 0, s.c_str(), (int)s.size(), NULL, 0);
    wchar_t* buf = new wchar_t[len + 1];
    MultiByteToWideChar(CP_ACP, 0, s.c_str(), (int)s.size(), buf, len);
    buf[len] = 0;
    std::wstring w = buf;
    delete[] buf;
    return w;
}

// ==================== DLL入口 ====================
BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID) {
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(h);
        id = GetCurrentThreadId();

        // 只有 ENABLE_LOG=1 时才创建日志文件
#if ENABLE_LOG
        std::string logPath = GetDllDir() + "\\hid.log";
        g_log_file.open(logPath, std::ios::out | std::ios::trunc);
        if (g_log_file.is_open()) {
            Log("========================================");
            Log("HID DLL 启动 (调试模式 + 崩溃捕获)");
            Log("皮肤文件夹: " + std::string(SKIN_FOLDER_NAME));
            Log("特征码扫描: " + std::string(USE_PATTERN_SCAN ? "启用" : "禁用"));
            Log("硬件断点: " + std::string(ENABLE_HARDWARE_BREAKPOINT ? "启用" : "禁用"));
            Log("过崩溃1补丁: " + std::string(ENABLE_CRASH_PATCH1 ? "启用" : "禁用"));
            Log("过崩溃2补丁: " + std::string(ENABLE_CRASH_PATCH2 ? "启用" : "禁用"));
            Log("========================================");
            Log("【调试模式】崩溃补丁已关闭，等待崩溃...");
            Log("崩溃地址会被记录到日志中");
            Log("========================================");
        }
#endif

        MH_Initialize();

        if (!InitAddresses()) {
#if ENABLE_LOG
            Log("地址初始化失败！");
#endif
            MessageBoxA(nullptr, "地址初始化失败！\n游戏版本可能不兼容。", "HID Error", MB_OK | MB_ICONERROR);
            return FALSE;
        }

        std::string skinPath = GetAppPath() + "\\DATA\\FINAL\\" + SKIN_FOLDER_NAME;
        Log("皮肤路径: " + skinPath);
        FindWAD(A2W(skinPath));

        if (vec_path.size() > 0) {
#if ENABLE_CRASH_PATCH1
            Log("应用 WadCheck 补丁...");
            WriteMem((void*)g_WadCheck, wad_check_Buff, sizeof(wad_check_Buff));
#else
            Log("【调试】WadCheck 补丁已禁用，让它崩溃！");
#endif
#if ENABLE_CRASH_PATCH2
            Log("应用 WadRepeat 补丁...");
            WriteMem((void*)g_WadRepeat, wad_repeat_Buff, sizeof(wad_repeat_Buff));
#else
            Log("【调试】WadRepeat 补丁已禁用，让它崩溃！");
#endif
            _beginthreadex(0, 0, (_beginthreadex_proc_type)BreakPoint, 0, 0, 0);
            Log("BreakPoint线程已启动");
        } else {
            Log("没有WAD文件，跳过");
        }

        Log("DLL初始化完成");
        Log("========================================");
    } else if (reason == DLL_PROCESS_DETACH) {
        MH_Uninitialize();
#if ENABLE_LOG
        if (g_log_file.is_open()) {
            Log("DLL卸载");
            g_log_file.close();
        }
#endif
    }
    return TRUE;
}